(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_d6d72620._.js",
  "static/chunks/apps_web_app_(auth)_layout_tsx_86bab8c1._.js"
],
    source: "dynamic"
});
